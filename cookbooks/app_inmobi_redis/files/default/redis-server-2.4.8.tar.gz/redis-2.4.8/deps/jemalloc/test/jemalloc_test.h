/*
 * This header should be included by tests, rather than directly including
 * jemalloc/jemalloc.h, because --with-install-suffix may cause the header to
 * have a different name.
 */
#include "jemalloc/jemalloc.h"
